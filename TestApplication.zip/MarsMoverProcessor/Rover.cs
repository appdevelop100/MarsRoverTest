﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    public class Rover
    {
        public int RoverId { get; set; }

        public TravelOrientation CurrentPosition { get; set; }

        /// <summary>
        /// for historical tracking.
        /// /// </summary>
        public TravelOrientation PreviousPosition { get; set; }

        public bool hasMoved { get; set; }
    }

}
