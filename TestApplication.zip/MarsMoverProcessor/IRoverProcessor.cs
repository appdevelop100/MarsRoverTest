﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    public interface IRoverProcessor
    {
        void Move(string movementValues, Rover rover, LandGrid grid);
    }
}
