﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    /// <summary>
    /// Core Mars Rover Processor
    /// </summary>
    public class RoverProcessor : IRoverProcessor
    { 
         
        public void Move(string movementValues, Rover rover, LandGrid grid)
        {
            var newPos = TravelOrientation.Clone(rover.CurrentPosition); 

            foreach(char val in movementValues) {
                if(val == MovementConstants.Left || val == MovementConstants.Right)
                {
                    newPos.Orientation = DetermineOrientation(newPos.Orientation, val);
                }
                else if (val == MovementConstants.Move)
                {
                    if (newPos.Orientation == CompassOrientation.North)
                    {
                        newPos.Y++;
                    }
                    else if (newPos.Orientation == CompassOrientation.South)
                    {
                        newPos.Y--;
                    }
                    else if (newPos.Orientation == CompassOrientation.East)
                    {
                        newPos.X++;
                    }
                    else if (newPos.Orientation == CompassOrientation.West)
                    {
                        newPos.X--;
                    }
                }
                else {
                    throw new InvalidOperationException(string.Format("Unexpected value: '{0}' - we only support L,R or M currently.", val));
                }
            }
            //No point in moving to an invalid location so we must validate before assigning to our Rover
            ValidatePosition(newPos, grid);

            //ensure we aren't moving back to the same place
            if (newPos.X == rover.CurrentPosition.X && newPos.Y == rover.CurrentPosition.Y
                && newPos.Orientation == rover.CurrentPosition.Orientation)
            {
                return;  //move isn't needed as target is the same
            }
            rover.PreviousPosition = rover.CurrentPosition;
            rover.CurrentPosition = newPos; //simulates a move in a simple way
            rover.hasMoved = true;
            //refresh grid
            grid.Matrix[rover.CurrentPosition.X, rover.CurrentPosition.Y] = rover.RoverId;
            grid.Matrix[rover.PreviousPosition.X, rover.PreviousPosition.Y] = default(int);  //just for ref to know where each rover is

        }

        private void ValidatePosition(TravelOrientation requiredPos, LandGrid grid)
        {
            if (requiredPos.X < grid.Matrix.GetLowerBound(0) || requiredPos.Y < grid.Matrix.GetLowerBound(1))
            {
                throw new ApplicationException("Invalid position of either X or Y coordinates provided  - outside the Land range");
            }
            if (requiredPos.X > grid.Matrix.GetUpperBound(0) || requiredPos.Y > grid.Matrix.GetUpperBound(1))
            {
                throw new ApplicationException("Invalid position of either X or Y coordinates provided - outside the Land range (upper max)");
            }
 	        //To prevent collision ensure no other Rover is also on the desired grid
            if (grid.Matrix[requiredPos.X, requiredPos.Y] != default(int))
            {
                throw new ApplicationException(string.Format("There is currently a Rover situated at desired grid position: {0}, {1} ", requiredPos.X, requiredPos.Y));
            }
        }

        private CompassOrientation DetermineOrientation(CompassOrientation current, char direction)
        {
            if (direction == MovementConstants.Left && current == CompassOrientation.North)
                return CompassOrientation.West;  //handle other way (anti-clockwise from North which starts from 0)
            else if (direction == MovementConstants.Right && current == CompassOrientation.West)
                return CompassOrientation.North;  //handle going to North
            else if (direction == MovementConstants.Left)
                return (CompassOrientation)(int)current - 90;
            else
                return (CompassOrientation)(int)current + 90;
        }
    }
}
