﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    /// <summary>
    /// Positional class with direction
    /// </summary>
    public class TravelOrientation : Position
    {

        public TravelOrientation(int x, int y, CompassOrientation orientation)
        {
            X = x;
            Y = y;
            Orientation = orientation;
        }

        public static TravelOrientation Clone(TravelOrientation pos)
        {
            return new TravelOrientation(pos.X, pos.Y, pos.Orientation);
        }

        public CompassOrientation Orientation { get; set; }
    }
}
