﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    public static class MovementConstants
    {
        public const char Left = 'L';
        public const char Right = 'R';
        public const char Move = 'M';
    }

}
