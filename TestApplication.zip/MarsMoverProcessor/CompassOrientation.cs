﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    public enum CompassOrientation
    {
        North = 0,
        East = 90,
        South = 180,
        West = 270
    }
}
