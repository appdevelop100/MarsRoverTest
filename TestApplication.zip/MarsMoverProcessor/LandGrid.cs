﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    /// <summary>
    /// Land Grid
    /// </summary>
    public class LandGrid
    {
        public LandGrid(Position maxUpperPlateuPosition)
        {
            MaxUpperPlateuPosition = maxUpperPlateuPosition;
            Matrix = new int[maxUpperPlateuPosition.X + 1, maxUpperPlateuPosition.Y + 1];  //increase by 1 as X and Y are 0 based 
        }

        public Position MaxUpperPlateuPosition { get; set; }

        /// <summary>
        /// Contains a matrix which has the Rover Id's on it
        /// </summary>
        public int[,] Matrix { get; set; }
    }
}
