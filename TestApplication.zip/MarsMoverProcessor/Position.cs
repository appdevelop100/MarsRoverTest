﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsMoverProcessor
{
    /// <summary>
    /// x,y coordinates class - 0 based dimensions
    /// </summary>
    public class Position
    {

        public int X { get; set; }
        public int Y { get; set; }
    }
}
