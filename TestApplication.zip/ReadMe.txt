Mars Rover Test App
===================

Developed and Tested with VS 2013 Community Edition.

Requires: 
	.NET 4.5
	NUnit Test Adapter - VS Extension for Unit Testing.