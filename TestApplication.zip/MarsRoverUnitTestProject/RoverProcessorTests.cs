﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MarsMoverProcessor;

namespace MarsRoverUnitTestProject
{
    [TestClass]
    public class RoverProcessorTests
    {
        [TestMethod]
        public void TestMoving_Move_Expected10East()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);
            Rover rover = new Rover(){
                RoverId = 1,
                CurrentPosition = new TravelOrientation(x:0, y:0, orientation: CompassOrientation.North)
            }; 

            var expectedTargetPosition = new TravelOrientation(x:1, y:0, orientation: CompassOrientation.East);

            RoverProcessor proc = new RoverProcessor();
            proc.Move("RM", rover, grid);

            Assert.IsTrue(IsValid(rover, expectedTargetPosition));
        }

        [TestMethod]
        public void TestMoving_Move_Expected13North()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);

            //Current: 1 2 N and Expected: 1 3 N using LMLMLMLMM
            Rover rover = new Rover()
            {
                RoverId = 1,
                CurrentPosition = new TravelOrientation(x: 1, y: 2, orientation: CompassOrientation.North)
            };

            var expectedTargetPosition = new TravelOrientation(x: 1, y: 3, orientation: CompassOrientation.North);

            RoverProcessor proc = new RoverProcessor();
            proc.Move("LMLMLMLMM", rover, grid);

            Assert.IsTrue(IsValid(rover, expectedTargetPosition));
        }

        [TestMethod]
        public void TestMoving_Move_Expected51East()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);

            //Current: 3 3 E and Expected: 5 1 E using MMRMMRMRRM
            Rover rover = new Rover()
            {
                RoverId = 1,
                CurrentPosition = new TravelOrientation(x: 3, y: 3, orientation: CompassOrientation.East)
            };

            var expectedTargetPosition = new TravelOrientation(x: 5, y: 1, orientation: CompassOrientation.East);

            RoverProcessor proc = new RoverProcessor();
            proc.Move("MMRMMRMRRM", rover, grid);

            Assert.IsTrue(IsValid(rover, expectedTargetPosition));
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void TestMoving_Move_ExpectedInvalidPositionOutsideLowerRangeLandTest()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);

            //Current: 0 0 W and Expected: Error as we are going to the left of the land (unchartered territory)
            Rover rover = new Rover()
            {
                RoverId = 1,
                CurrentPosition = new TravelOrientation(x: 0, y: 0, orientation: CompassOrientation.West)
            };
            RoverProcessor proc = new RoverProcessor();
            proc.Move("MM", rover, grid);
            Assert.Fail("We should not reach here as move outside land was not valid");
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void TestMoving_Move_ExpectedInvalidPositionOutsideUpperRangeLandTest()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);

            //Current: 0 0 W and Expected: Error as we are going to the left of the land (unchartered territory)
            Rover rover = new Rover()
            {
                RoverId = 1,
                CurrentPosition = new TravelOrientation(x: 5, y: 4, orientation: CompassOrientation.North)
            };
            RoverProcessor proc = new RoverProcessor();
            proc.Move("MMRM", rover, grid);
            Assert.Fail("We should not reach here as move outside land was not valid");
        }

        private bool IsValid(Rover rover, TravelOrientation expectedTargetPosition)
        {
            //TO-DO - Could use IEquatable to simplify comparison
            return rover.hasMoved == true && rover.CurrentPosition.X == expectedTargetPosition.X
                && rover.CurrentPosition.Y == expectedTargetPosition.Y
                && rover.CurrentPosition.Orientation == expectedTargetPosition.Orientation;
        }
    }
}
