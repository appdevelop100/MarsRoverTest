﻿using MarsMoverProcessor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestMarsRoverApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MARS ROVER TEST");
            MoveExpected10East();
            MoveExpected13North();
            MoveExpected51East();
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
        private static void OutputPosition(Rover rover, bool after)
        {
            if (!after)
            {
                Console.WriteLine();
            }
            Console.WriteLine(string.Format("Rover: {0} - {1} {2}, {3} and Direction: {4}", rover.RoverId, !after ? "Before" : "After", rover.CurrentPosition.X, rover.CurrentPosition.Y, rover.CurrentPosition.Orientation));
        }
        private static void MoveExpected10East()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);
            Rover rover = new Rover()
            {
                RoverId = 1,
                CurrentPosition = new TravelOrientation(x: 0, y: 0, orientation: CompassOrientation.North)
            };
            OutputPosition(rover, false);

            var expectedTargetPosition = new TravelOrientation(x: 1, y: 0, orientation: CompassOrientation.East);

            RoverProcessor proc = new RoverProcessor();

            string movement = "RM";
            Console.WriteLine("Moving: " + movement);
            proc.Move(movement, rover, grid);

            OutputPosition(rover, true);
        }
         
        private static void MoveExpected13North()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);

            //Current: 1 2 N and Expected: 1 3 N using LMLMLMLMM
            Rover rover = new Rover()
            {
                RoverId = 2,
                CurrentPosition = new TravelOrientation(x: 1, y: 2, orientation: CompassOrientation.North)
            };
            OutputPosition(rover, false);
            var expectedTargetPosition = new TravelOrientation(x: 1, y: 3, orientation: CompassOrientation.North);

            RoverProcessor proc = new RoverProcessor();

            string movement = "LMLMLMLMM";
            Console.WriteLine("Moving: " + movement);

            proc.Move(movement, rover, grid);

            OutputPosition(rover, true);
        }

        private static void MoveExpected51East()
        {
            Position maxUpper = new Position() { X = 5, Y = 5 };

            LandGrid grid = new LandGrid(maxUpper);

            //Current: 3 3 E and Expected: 5 1 E using MMRMMRMRRM
            Rover rover = new Rover()
            {
                RoverId = 3,
                CurrentPosition = new TravelOrientation(x: 3, y: 3, orientation: CompassOrientation.East)
            };

            OutputPosition(rover, false);
            var expectedTargetPosition = new TravelOrientation(x: 5, y: 1, orientation: CompassOrientation.East);

            RoverProcessor proc = new RoverProcessor();

            string movement = "MMRMMRMRRM";
            Console.WriteLine("Moving: " + movement);
            proc.Move(movement, rover, grid);

            OutputPosition(rover, true);
        }
    }
}
